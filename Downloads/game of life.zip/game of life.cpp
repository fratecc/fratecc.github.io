#include<iostream>
#include<iomanip>
#include<cmath>
#include<ctime>
#include<cstdio>
#include<string>
#include<cstdlib>
using namespace std;

const int campoX=35;
const int campoY=45;
int vicini(int, int);
class Cellule{
    int alive;
    
    
    public:
    void show(){
            cout<<setw(2)<<((alive==1)?char(178):char(176));
        } 
    
    void vivo(){
        alive=1;
    }
    int is_vivo(){
        if(alive==1){
            return 1;
        }
        else return 0;
    }
    void morto(){
        alive=0;
    }
    
    
    
};


Cellule campo[campoX][campoY];
void stampa_campo(){
    for(int i=0; i<campoX; i++){
        for(int j=0; j<campoY; j++){
            campo[i][j].show();
        }
        cout<<endl;
    }
}
void inizializza(){
    campo[5][5].vivo();
    campo[5][6].vivo();
    campo[5][7].vivo();
    campo[6][5].vivo();
    campo[6][6].vivo();
    campo[6][7].vivo();
    campo[7][5].vivo();
    campo[7][6].vivo();
    campo[7][7].vivo();
    campo[8][5].vivo();
    campo[8][6].vivo();
    campo[8][7].vivo();
    campo[9][5].vivo();
    campo[9][6].vivo();
    campo[9][7].vivo();
    campo[10][5].vivo();
    campo[10][8].vivo();
    campo[10][7].vivo();
}

void controllo(){
    char c;
    for(int i=0; i<campoX; i++){//qui "scannerizzo" ogni cellula
        for(int j=0; j<campoY; j++){
            
            if(campo[i][j].is_vivo()==1){//se la cellula � viva)
                //calcolo cellule vive nel quadrato
                int v = vicini(i,j);
                if(v==3 || v==2){campo[i][j].vivo();}//se il contatore � a 3 o a 2 la cellula rimane viva
                else {campo[i][j].morto();}//se il contatore � qualsiasi altro numero la cellula muore
            }
            
            else if(campo[i][j].is_vivo()!=1){
                int v=vicini(i,j);
                if(v==3) campo[i][j].vivo();
                else campo[i][j].morto();
            }
        }
    }
}

int vicini(int i, int j){
    int b=0;
    for(int m=i-1; m<=i+1; m++){
        for(int n=j-1; n<=j+1; n++){
            //cout<<m<<" "<<n;
            if (m<0 || m>24 || n<0 || n>34 )continue;
            if (campo[m][n].is_vivo()==1){
                b=b+1;
            }
        }
    }
    return b;
}


int main(){
    inizializza();
    while(true){
        stampa_campo();
        controllo();
        system("cls");
    }
    system("pause");
}
